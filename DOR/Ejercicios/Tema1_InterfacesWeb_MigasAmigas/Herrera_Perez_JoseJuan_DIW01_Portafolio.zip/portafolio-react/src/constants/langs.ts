export const LANGUAGE = [
    { label: "Spanish", code: "es" },
    { label: "English", code: "en" },
]
