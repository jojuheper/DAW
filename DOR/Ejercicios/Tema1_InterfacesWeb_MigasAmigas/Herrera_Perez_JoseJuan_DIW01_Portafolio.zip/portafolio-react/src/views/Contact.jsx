import { FormContact } from "../components/contact/form/FormContact";

export const Contact = () => {
  return (
    <div>
      <div>Contact</div>
      <FormContact />
    </div>
  );
};
