

export const Home = () => {
  return (
    <div>
      <div>Body</div>
    </div>
  );
};
