export const Curriculum = () => {
  return (
    <div>Curriculum</div>
  )
}
