export const langs = [
  { label: "Spanish", code: "es" },
  { label: "Portuguese", code: "pt" },
];
