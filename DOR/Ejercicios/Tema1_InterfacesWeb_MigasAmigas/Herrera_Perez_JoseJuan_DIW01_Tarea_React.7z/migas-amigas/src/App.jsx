import { useTranslation } from "react-i18next";
import "./App.css";
import { MisRutas } from "./router/MisRutas";
import { LanguageProvider } from "./context/LanguageProvider";

function App() {
  const { t } = useTranslation();
  return (
    <LanguageProvider>
      <div>
        <h1>{t("titleApp")}</h1>
        <MisRutas />
      </div>
    </LanguageProvider>
  );
}

export default App;
