import { useTranslation } from "react-i18next";

export const Contacto = () => {
  const { t } = useTranslation();

  return (
    <div>
      <h1>{t("contactPage.titleContact")}</h1>
    </div>
  );
};
