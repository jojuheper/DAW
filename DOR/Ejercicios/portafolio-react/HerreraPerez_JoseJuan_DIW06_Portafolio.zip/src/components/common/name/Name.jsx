export const Name = () => {
  return <h1 className="text-2xl font-bold text-blue-600 col-span-6 md:col-span-4">JJ Herrera</h1>;
};
