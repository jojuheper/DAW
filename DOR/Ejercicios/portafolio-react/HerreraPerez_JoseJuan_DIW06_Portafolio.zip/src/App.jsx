import "./App.css";
import { MyRoutes } from "./router/MyRoutes";

function App() {
  return (
    <div className="px-3">
      <MyRoutes />
    </div>
  );
}

export default App;
