import { Icon } from "../icon/Icon";

export const SocialLink = () => {
  const facebook = "facebook";
  const instagram = "instagram";
  return (
    <div>
      <Icon icon={facebook} />
      <Icon icon={instagram} />
    </div>
  );
};
