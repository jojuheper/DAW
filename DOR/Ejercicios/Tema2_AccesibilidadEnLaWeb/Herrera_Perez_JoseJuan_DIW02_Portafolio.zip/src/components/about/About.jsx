export const About = () => {
  return (
    <div>
      <div>
        <div>quie eres</div>
      </div>
      <div>
        <img src="https://placehold.co/100x100" alt="Jose Juan" />
      </div>
    </div>
  );
};
