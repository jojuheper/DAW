import { Visit } from "../counter/Visit";

export const Footer = () => {
  return (
    <div>
      <div>Footer</div>
      <Visit />
    </div>
  );
};
