import './App.css'
import { MyRoutes } from './router/MyRoutes'

function App() {

  return (
    <>
      <MyRoutes />
    </>
  )
}

export default App
