export const langs = [
  { label: "Español", code: "es" },
  { label: "Português", code: "pt" },
];
