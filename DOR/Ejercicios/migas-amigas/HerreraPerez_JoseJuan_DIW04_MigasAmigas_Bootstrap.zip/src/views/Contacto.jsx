import { Contact } from "../components/common/contact/Contact";

export const Contacto = () => {

  return (
    <div className="contact w-100 h-100 m-0 p-0">
      <Contact />
    </div>
  );
};
