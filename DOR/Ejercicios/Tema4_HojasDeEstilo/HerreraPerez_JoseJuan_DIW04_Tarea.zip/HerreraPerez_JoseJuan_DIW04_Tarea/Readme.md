## Layout

Para este layout si se aplica los anchos que tiene de 920px para el header y 960px para el footer, queda mal centrada la página, por ello hemos cambiado a 1280px para que cuadre la página, de la otra manera nos lleva mucho trabajo y agregar más elementos innecesarios

## Author

José Juan Herrera Pérez
DIW04 Hojas de Estilo Tarea