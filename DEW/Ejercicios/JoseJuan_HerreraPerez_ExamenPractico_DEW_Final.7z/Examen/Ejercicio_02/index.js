let vehicle;

class Vehicle {

    constructor(mark, model, color, year, licencePlate) {
        this.mark = mark;
        this.model = model;
        this.color = color;
        this.year = year;
        this.licencePlate = licencePlate;
        this.observation = [];

        this.showData();
    }

    setMark() {
        if (this.confirmSet()) this.mark = prompt('Ingrese Marca');
        this.showData();
    }
    setModel() {
        if (this.confirmSet()) this.model = prompt('Ingrese Modelo');
        this.showData();
    }
    setColor() {
        if (this.confirmSet()) this.color = prompt('Ingrese Color');
        this.showData();
    }
    setYear() {
        if (this.confirmSet()) this.year = prompt('Ingrese Año (YYYY-MM-dd)');
        this.showData();
    }
    setLicencePlate() {
        if (this.confirmSet()) this.licencePlate = prompt('Ingrese Matrícula');
        this.showData();
    }

    addObservation(observation) {
        if (this.confirmSet()) this.observation.push(prompt('Ingrese Observación'));
        this.showObservation();
    }

    showData() {
        let textArea = document.getElementById('datosvehiculo');
        textArea.innerHTML = `
            Marca: ${this.mark},
            Modelo: ${this.model},
            Color: ${this.color},
            Year: ${this.year},
            Matrícula: ${this.licencePlate},
        `;
    }

    showObservation() {
        let textArea = document.getElementById('observaciones');
        textArea.innerHTML = 'Observaciones: \n\n';
        if (this.observation.length > 0) {
            this.observation.forEach(element => {
                textArea.innerHTML += (element + '\n');
            });
        }
    }

    confirmSet() {
        return confirm('Confirma que quiere cambiar el dato?');
    }

}

function reloadPage() {
    self.location.reload();
}

function init(event) {
    event.preventDefault();

    let regex = /[(0-9){4}\\s(a-zA-Z){1-3}]/;

    let mark = document.getElementById('marca').value;
    let model = document.getElementById('modelo').value;
    let color = document.getElementById('color').value;
    let year = document.getElementById('anho').value;;
    let licencePlate = document.getElementById('matricula').value;

    if (!regex.test(licencePlate)) {
        alert('No ha ingresado bien la matrícula');
        licencePlate.focus();
    }

    vehicle = new Vehicle(mark, model, color, year, licencePlate);

    vehicle.showData();
    vehicle.showObservation();
}

document.getElementById('modificarMarca').addEventListener('click', () => vehicle.setMark());
document.getElementById('modificarModelo').addEventListener('click', () => vehicle.setModel());
document.getElementById('modificarColor').addEventListener('click', () => vehicle.setColor());
document.getElementById('modificarAnho').addEventListener('click', () => vehicle.setYear());
document.getElementById('modificarMatricula').addEventListener('click', () => vehicle.setLicencePlate());

document.getElementById('agregarObs').addEventListener('click', () => vehicle.addObservation());

document.getElementById('crearnuevo').addEventListener('click', (event) => init(event));
document.getElementById('limpiar').addEventListener('click', () => reloadPage());
